# Curso de Almacenamiento y Captura de datos

Repositorio del curso Almacenamiento y Captura de datos del Magíster en Data Science de la Universidad del Desarrollo.
